export const environment = {
  production: true,
  apiUrl: 'http://nodecommerce-env.tqhbbayxip.us-west-2.elasticbeanstalk.com/api/pets'
};
