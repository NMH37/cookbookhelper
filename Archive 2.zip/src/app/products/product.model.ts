export interface Product {
  _id?: string;
  name: string;
  type: string;
  description: string;
  skill1?: string;
  skill2?: string;
  skill3?: string;
  likes?: number;
}
